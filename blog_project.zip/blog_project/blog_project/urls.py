from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='homepage'),  # Home Page URL
    path('author/', include('author.urls')),  # Author Page URL
    path('post/', include('posts.urls')),  # Posts Page URL
    path('category/', include('categories.urls')),  # Categories Page URL
    path('search/', views.search_blog, name='search_blog'),  # Search Functionality
]