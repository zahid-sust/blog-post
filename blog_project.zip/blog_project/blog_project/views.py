# views.py
from django.shortcuts import render
from posts.models import Post  # Import Post from the correct app

def home(request):
    search_term = request.GET.get('search', '')  # Get the single search term

    # Base queryset for all posts
    posts = Post.objects.all()

    # Filter by title or category if a search term is provided
    if search_term:
        posts = posts.filter(
            title__icontains=search_term
        ) | posts.filter(
            category__name__icontains=search_term
        )

    context = {
        'data': posts,  # 'data' variable used in home.html template
        'search_term': search_term,
    }
    return render(request, 'home.html', context)

def search_blog(request):
    return home(request)  # Delegate search to the home view
